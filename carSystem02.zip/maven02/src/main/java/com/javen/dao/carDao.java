package com.javen.dao;

import java.util.List;

import com.javen.model.Login;
import com.javen.model.car;
import com.javen.model.page_count;

public interface carDao {

	public  List<car> selectAll(page_count page);
	
	public int updateByPrimaryKey(car Car);
	
	public int deleteByPrimaryKey(int id);
	
	public int insert(car Car);
	
	public int selectAll_count();
}
