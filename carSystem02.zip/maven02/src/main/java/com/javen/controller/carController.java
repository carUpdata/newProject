package com.javen.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javan.util.ObjtoLayJson;
import com.javen.model.Login;
import com.javen.model.car;
import com.javen.model.dataCheck;
import com.javen.model.page_count;
import com.javen.service.carService;

@Controller
@RequestMapping("/cars")
public class carController {

	@Autowired
	private carService CarService;
	
	
	@ResponseBody
	@RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String selectAll(HttpServletRequest Request) throws Exception{
		Request.setCharacterEncoding("utf-8");  
		String pageString = Request.getParameter("page");
    	String limitString = Request.getParameter("limit");
    	System.out.println(pageString+" "+limitString);
    	Integer pageInteger = Integer.valueOf(pageString);
    	Integer limitInteger = Integer.valueOf(limitString);
    	page_count page = new page_count();
    	page.setPage(pageInteger-1);
    	page.setLimit(limitInteger);
    	page.setOffset((pageInteger-1)*limitInteger);
    	List<car> logins = CarService.selectAll(page);
      	String[] colums = {"id","car_name","car_mile","car_src","flag","car_id"};
    	String data = ObjtoLayJson.ListtoJson(logins, colums);
    	System.out.println(data);
        return data; 
	}
	
	@ResponseBody
	@RequestMapping(value="/selectAll_count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String selectAll_count(){
		int count = CarService.selectAll_count();
		System.out.println(count);
		String data = "{\"data\":\"200\",\"count\":\""+count+"\"}";
		 return data;
		
	}
	
	@ResponseBody
	@RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	public String deleteByPrimaryId(int id) {
		 CarService.deleteByPrimaryKey(id);
		 String data ="{\"data\":\"删除成功\"}";
		return data;
	}
	
	@ResponseBody
	@RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String insert(String car_name,String car_mile,String car_src,String flag,String car_id) {
		car Car = new car();
		String data = "";
    	try {
    		Car.setCar_mile(dataCheck.check2(car_mile));
    		Car.setFlag(dataCheck.check3(flag));
    		Car.setCar_id(dataCheck.check4(car_id));
    		 data="{\"data\":\"插入成功\"}";
    	}catch(Exception e){
    		data = "{\"data\":"+e.getMessage()+"}" ;
    	}
    	Car.setCar_name(car_name);
    	Car.setCar_src(car_src);
    	CarService.insert(Car);
		return data;
	}
	
		@ResponseBody
	    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	    public String update(String id,String car_name,String car_mile,String car_src,String flag,String car_id) throws Exception {
	    	car Car = new car();
	    	String data = "";
	    	try {
	    		Car.setId(dataCheck.check1(id));
	    		Car.setCar_mile(dataCheck.check2(car_mile));
	    		Car.setFlag(dataCheck.check3(flag));
	    		Car.setCar_id(dataCheck.check4(car_id));
	    		 data = "{\"data\":\"修改成功\"}"; 
	    	}catch(Exception e){
	    		data = "{\"data\":"+e.getMessage()+"}" ;
	    	}
	    	Car.setCar_name(car_name);
	    	Car.setCar_src(car_src);
	    	CarService.updateByPrimaryKey(Car);
	        return data; 
	    }
	

}
