package com.javen.service;

import java.util.List;

import com.javen.model.car;
import com.javen.model.page_count;

public interface carService {

	public List<car> selectAll(page_count page);
	
	public int updateByPrimaryKey(car Car);
	
	public int deleteByPrimaryKey(int id);
	
	public int insert(car Car);
	
	public int selectAll_count();
}
