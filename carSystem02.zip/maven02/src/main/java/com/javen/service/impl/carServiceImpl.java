package com.javen.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import com.javen.dao.carDao;
import com.javen.model.Login;
import com.javen.model.car;
import com.javen.model.page_count;
import com.javen.service.carService;

@Service
public class carServiceImpl implements carService{

	@Resource
	private carDao carDao;
	
	public List<car> selectAll(page_count page) {
		// TODO Auto-generated method stub
		return this.carDao.selectAll(page);
	}
	
	public int updateByPrimaryKey(car Car) {
		return this.carDao.updateByPrimaryKey(Car);
	}
	
	public int deleteByPrimaryKey(int id) {
		return  this.carDao.deleteByPrimaryKey(id);	
	}
	
	public int insert(car Car) {
		return this.carDao.insert(Car);
	}
	
	public int selectAll_count() {
		return  this.carDao.selectAll_count();
	}
}
