package com.javen.model;

public class car {
	
	private int id;
	private String car_name;
	private int car_mile;
	private String car_src;
	private int flag;
	private int car_id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCar_name() {
		return car_name;
	}

	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}

	public int getCar_mile() {
		return car_mile;
	}

	public void setCar_mile(int car_mile) {
		this.car_mile = car_mile;
	}

	public String getCar_src() {
		return car_src;
	}

	public void setCar_src(String car_src) {
		this.car_src = car_src;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public int getCar_id() {
		return car_id;
	}

	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}

	@Override
	public String toString() {
		return "car [id=" + id + ", car_name=" + car_name + ", car_mile=" + car_mile + ", car_src=" + car_src
				+ ", flag=" + flag + ", car_id=" + car_id + "]";
	}

	
}
