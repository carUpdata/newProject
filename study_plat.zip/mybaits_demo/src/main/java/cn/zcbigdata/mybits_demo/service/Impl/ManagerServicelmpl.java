package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.TTeacherTake_Leave;
import cn.zcbigdata.mybits_demo.mapper.ManagerMapper;
import cn.zcbigdata.mybits_demo.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManagerServicelmpl implements ManagerService {

    @Autowired
    private ManagerMapper managerMapper;

    //批假模块
    public List<TTeacherTake_Leave> mTeacherTakeLeave(){
        return managerMapper.mTeacherTakeLeave();
    }

    public int mManagerUpdateTakeLeave(TTeacherTake_Leave tteachertake_leave){
        return managerMapper.mManagerUpdateTakeLeave(tteachertake_leave);
    }

}
