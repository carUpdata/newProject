package cn.zcbigdata.mybits_demo.entity;

public class THomeWork_Son {
    private Integer id;
    private String homework_name;
    private String stu_name;
    private String homework_content;
    private String teacher_reply;
    private Integer flag_reply;
    private Integer flag_finish;
    private String homework_write_time;
    private String homework_leave_time;
    private Integer stu_id;
    private Integer homework_count;
    private Integer teacher_id;

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getHomework_leave_time() {
        return homework_leave_time;
    }

    public void setHomework_leave_time(String homework_leave_time) {
        this.homework_leave_time = homework_leave_time;
    }

    public Integer getHomework_count() {
        return homework_count;
    }

    public void setHomework_count(Integer homework_count) {
        this.homework_count = homework_count;
    }

    public Integer getFlag_reply() {
        return flag_reply;
    }

    public void setFlag_reply(Integer flag_reply) {
        this.flag_reply = flag_reply;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getHomework_write_time() {
        return homework_write_time;
    }

    public void setHomework_write_time(String homework_write_time) {
        this.homework_write_time = homework_write_time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getHomework_content() {
        return homework_content;
    }

    public void setHomework_content(String homework_content) {
        this.homework_content = homework_content;
    }

    public String getTeacher_reply() {
        return teacher_reply;
    }

    public void setTeacher_reply(String teacher_reply) {
        this.teacher_reply = teacher_reply;
    }

    public Integer getFlag_finish() {
        return flag_finish;
    }

    public void setFlag_finish(Integer flag_finish) {
        this.flag_finish = flag_finish;
    }

    @Override
    public String toString() {
        return "THomeWork_Son{" +
                "id=" + id +
                ", homework_name='" + homework_name + '\'' +
                ", stu_name='" + stu_name + '\'' +
                ", homework_content='" + homework_content + '\'' +
                ", teacher_reply='" + teacher_reply + '\'' +
                ", flag_reply=" + flag_reply +
                ", flag_finish=" + flag_finish +
                ", homework_write_time='" + homework_write_time + '\'' +
                ", homework_leave_time='" + homework_leave_time + '\'' +
                ", stu_id=" + stu_id +
                ", homework_count=" + homework_count +
                ", teacher_id=" + teacher_id +
                '}';
    }
}
