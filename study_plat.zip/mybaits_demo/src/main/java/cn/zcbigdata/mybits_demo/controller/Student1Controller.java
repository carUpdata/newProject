package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.Student1Service;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/student1")
public class Student1Controller {
    @Autowired
    private Student1Service student1Service;

    private static final Logger LOGGER = Logger.getLogger(Student1Controller.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/slogin")
    public String stologin(){
        LOGGER.info("Go To slogin.html");
        return "slogin";
    }

    @RequestMapping("/shomeworkselectall")
    public String shomeworkselectall(){
        LOGGER.info("Go To studentWriteHomeWork.html");
        return "studentWriteHomeWork";
    }
    @RequestMapping("/stakeleave")
    public String stakeleave(){
        LOGGER.info("Go To studentTakeLeave.html");
        return "studentTakeLeave";
    }
    @RequestMapping("/download")
    public String download(){
        LOGGER.info("Go To studentClassScheduleDownload.html");
        return "studentClassScheduleDownload";
    }

    @RequestMapping("/studentwritehomeworkson")
    public String studentwritehomeworkson(){
        LOGGER.info("Go To studentWriteHomeWorkSon.html");
        return "studentWriteHomeWorkSon";
    }


    //登录模块
    @RequestMapping(value="/stologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String stologin(HttpServletRequest request, Model model){
        String stu_id = request.getParameter("stu_id");
        String stu_password = request.getParameter("stu_password");
        Integer stu_idInteger = Integer.valueOf(stu_id);


        EasyStudentLogin easystudentlogin = new EasyStudentLogin();
        easystudentlogin.setStu_id(stu_idInteger);
        easystudentlogin.setStu_password(stu_password);
        boolean x = student1Service.slogin(easystudentlogin,request);

        LOGGER.info("stologin接收参数"+" " +easystudentlogin);

        if (x){
            HttpSession session = request.getSession();
            session.setAttribute("stu_id", stu_idInteger);

//            System.out.println("------------------");
//            System.out.println(session.getAttribute("stu_id"));

            LOGGER.info("登录成功");
            return "student";

        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }

    //作业模块
    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectAll(HttpServletRequest request, Model model){

        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");

        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+studentIdInteger);//日志打印

        List<THomeWork> shomeworklist = student1Service.sHomeWorkSelectAll(studentIdInteger);

        String data = gson.toJson(shomeworklist);
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+data);//日志打印
        return data;
        //}
        //String data = "{\"data\":\"studentID不能为空！\"}";

        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectSingle(HttpServletRequest request, Model model){
        String homework_name = request.getParameter("homework_name");
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");
        StudentSelect studentselect = new StudentSelect();
        studentselect.setHomework_name(homework_name);
        studentselect.setStu_id(studentIdInteger);

        THomeWork_Son thomework = student1Service.sHomeWorkSelectSingle(studentselect);
        String data = gson.toJson(thomework);

        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+data);//日志打印
        return data;

        //String data = "{\"data\":\"ID不能为空！\"}";
        //return "data";
    }

    //教室布置的作业信息学生将其内容添加到数据库
    @ResponseBody
    @RequestMapping(value="/sHomeWorkInsertSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkInsertSingle(HttpServletRequest request, Model model) {
        String homework_name = request.getParameter("homework_name");
        Integer homeworkcountInteger = 0;
        Integer flag_reply = 0;
        Integer flag_finish = 0;

        String homework_leave_time = request.getParameter("homework_leave_time");
        String teacher_id = request.getParameter("teacher_id");
        Integer teacher_idInteger = Integer.valueOf(teacher_id);
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");


        THomeWork1 thomework1 = new THomeWork1();
        thomework1.setStu_id(studentIdInteger);
        thomework1.setHomework_name(homework_name);
        thomework1.setHomework_count(homeworkcountInteger);
        thomework1.setHomework_leave_time(homework_leave_time);
        thomework1.setTeacher_id(teacher_idInteger);
        thomework1.setFlag_reply(flag_reply);
        thomework1.setFlag_finish(flag_finish);

        LOGGER.info("thomework1接收参数" + " " + thomework1);//日志打印
        int x = student1Service.sHomeWorkInsertSingle(thomework1);
        System.out.println("x="+x);
        if (x == 1) {
            String data = gson.toJson(thomework1);
            LOGGER.info("sHomeWorkInsertSingle接收参数" + " " + data);//日志打印
            return data;
        }
        String data = "{\"data\":\"学生插入教师布置的数据失败！\"}";
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkUpdateSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkUpdateSingle(HttpServletRequest request, Model model){
        //String homeworkcountString = request.getParameter("homework_count");
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Date date = new Date();
        String homeworkfinishtime = date.toString();
        String homeworkcontentString = request.getParameter("homework_content");
        //Integer flag_finish = 1;
        String flag_finish = "1";
        THomeWork_Son thomeworkson = new THomeWork_Son();
        try {
            Integer flag_finish1 = dataCheck1.check4(flag_finish);
            thomeworkson.setFlag_finish(flag_finish1);
        }catch(Exception e) {
            return e.getMessage();
        }

        thomeworkson.setHomework_content(homeworkcontentString);
        thomeworkson.setHomework_write_time(homeworkfinishtime);
        thomeworkson.setId(IdInteger);

        //THomeWork thomework = new THomeWork();
        //Integer homeworkcountInteger = Integer.valueOf(homeworkcountString);
        //Integer homework_count = homeworkcountInteger+1;


        System.out.println(flag_finish);
        student1Service.sHomeWorkUpdateSingle(thomeworkson);
        System.out.println(thomeworkson);
        String data = "{\"data\":\"作业完成！\"}";
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");

        Integer flagInteger = 0;
        String studentNameString = request.getParameter("stu_name");
        String studentLeaveReasonString = request.getParameter("stu_leave_reason");
        String teacherIdString = request.getParameter("teacher_id");
        Integer teacherIdInteger = Integer.parseInt(teacherIdString);
        Date date = new Date();
        String studentLeaveTimeString = date.toString();

        //if (StringUtils.isNotEmpty(studentIdString)){
        TStudentTake_Leave tstudenttakeleave =  new TStudentTake_Leave();
        tstudenttakeleave.setStu_id(studentIdInteger);
        tstudenttakeleave.setFlag(flagInteger);
        tstudenttakeleave.setStu_name(studentNameString);
        tstudenttakeleave.setTeacher_id(teacherIdInteger);
        tstudenttakeleave.setStu_leave_reason(studentLeaveReasonString);
        tstudenttakeleave.setStu_leave_time(studentLeaveTimeString);
        student1Service.sTakeLeaveInsert(tstudenttakeleave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
        String data = gson.toJson(tstudenttakeleave) + "{\"data\":\"请假成功！\"}";
        return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");
        System.out.println(studentIdInteger);


        TStudentTake_Leave tstudenttake_leave = student1Service.sTakeLeaveSelect(studentIdInteger);
        String data = gson.toJson(tstudenttake_leave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttake_leave);//日志打印
        return data;

    }
}
