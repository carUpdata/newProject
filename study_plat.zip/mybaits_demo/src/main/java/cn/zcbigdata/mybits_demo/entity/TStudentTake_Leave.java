package cn.zcbigdata.mybits_demo.entity;

public class TStudentTake_Leave {
    private Integer id;
    private Integer stu_id;
    private String stu_name;
    private String stu_leave_reason;
    private String stu_leave_time;
    private Integer flag;
    private Integer teacher_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getStu_leave_reason() {
        return stu_leave_reason;
    }

    public void setStu_leave_reason(String stu_leave_reason) {
        this.stu_leave_reason = stu_leave_reason;
    }

    public String getStu_leave_time() {
        return stu_leave_time;
    }

    public void setStu_leave_time(String stu_leave_time) {
        this.stu_leave_time = stu_leave_time;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    @Override
    public String toString() {
        return "TStudentTake_Leave{" +
                "id=" + id +
                ", stu_id=" + stu_id +
                ", stu_name='" + stu_name + '\'' +
                ", stu_leave_reason='" + stu_leave_reason + '\'' +
                ", stu_leave_time='" + stu_leave_time + '\'' +
                ", flag=" + flag +
                ", teacher_id=" + teacher_id +
                '}';
    }
}
