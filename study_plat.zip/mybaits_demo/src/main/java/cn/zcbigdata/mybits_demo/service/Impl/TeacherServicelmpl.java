package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.mapper.TeacherMapper;
import cn.zcbigdata.mybits_demo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Service
public class TeacherServicelmpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    public Boolean tlogin(EasyStudentLogin easystudentlogin, HttpServletRequest request){
        Teacher teacher = teacherMapper.tlogin(easystudentlogin);
        if (teacher != null){
            HttpSession session = request.getSession();
            session.setAttribute("teacher_id", teacher.getId());
            return true;
        }
        return false;
    }

    //作业模块
    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id){
        return teacherMapper.tHomeWorkSelectAll(teacher_id);
    }

    public List<THomeWork_Son> tHomeWorkSelectSon(String homework_name){
        return teacherMapper.tHomeWorkSelectSon(homework_name);
    }

    public THomeWork_Son tHomeWorkSelectMySon(Integer id){
        return teacherMapper.tHomeWorkSelectMySon(id);
    }

    public int tHomeWorkUpdate(THomeWork_Son thomeworkson){
        return teacherMapper.tHomeWorkUpdate(thomeworkson);
    }

    public int tHomeWorkInsert(THomeWork thomework){

        return teacherMapper.tHomeWorkInsert(thomework);
    }

//    public int tHomeWorkInsert(HomeWork homework){
//
//        return teacherMapper.tHomeWorkInsert(homework);
//    }

    //请假模块
    public List<TStudentTake_Leave> tStudentTakeLeave(Integer teacher_id){
        return teacherMapper.tStudentTakeLeave(teacher_id);
    }

    public int tTeacherUpdateTakeLeave(TStudentTake_Leave tstudenttake_leave){
        return teacherMapper.tTeacherUpdateTakeLeave(tstudenttake_leave);
    }

    public int tTakeLeaveInsert(TTeacherTake_Leave tleave){
        return teacherMapper.tTakeLeaveInsert(tleave);
    }
}
