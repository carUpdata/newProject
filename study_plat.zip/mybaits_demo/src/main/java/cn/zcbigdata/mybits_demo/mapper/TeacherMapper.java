package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface TeacherMapper {

    public Teacher tlogin(EasyStudentLogin easystudentlogin);

    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id);

    public List<THomeWork_Son> tHomeWorkSelectSon(String homework_name);

    public THomeWork_Son tHomeWorkSelectMySon(Integer id);

    public int tHomeWorkUpdate(THomeWork_Son thomeworkson);

    public int tHomeWorkInsert(THomeWork thomework);
    //public int tHomeWorkInsert(HomeWork homework);

    public List<TStudentTake_Leave> tStudentTakeLeave(Integer teacher_id);

    public int tTeacherUpdateTakeLeave(TStudentTake_Leave tstudenttake_leave);

    public int tTakeLeaveInsert(TTeacherTake_Leave tleave);
}
