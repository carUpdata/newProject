package cn.zcbigdata.mybits_demo.entity;

public class Student1 {
    private Integer id;
    private Integer stu_id;
    private String stu_name;
    private String stu_grade;
    private Integer teacher_id;
    private String stu_password;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getStu_grade() {
        return stu_grade;
    }

    public void setStu_grade(String stu_grade) {
        this.stu_grade = stu_grade;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getStu_password() {
        return stu_password;
    }

    public void setStu_password(String stu_password) {
        this.stu_password = stu_password;
    }

    @Override
    public String toString() {
        return "Student1{" +
                "id=" + id +
                ", stu_id=" + stu_id +
                ", stu_name='" + stu_name + '\'' +
                ", stu_grade='" + stu_grade + '\'' +
                ", teacher_id=" + teacher_id +
                ", stu_password='" + stu_password + '\'' +
                '}';
    }
}
