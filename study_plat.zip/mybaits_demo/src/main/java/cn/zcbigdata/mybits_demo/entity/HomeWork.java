package cn.zcbigdata.mybits_demo.entity;

public class HomeWork {
    private Integer id;
    private String homework_name;
    private String homework_content;
    private Integer homework_count;
    private String homework_leavetime;
    private String homework_finishtime;
    private String homework_reply;
    private Integer flag_reply;
    private Integer flag_finish;
    private Integer stu_id;
    private Integer teacher_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    public String getHomework_content() {
        return homework_content;
    }

    public void setHomework_content(String homework_content) {
        this.homework_content = homework_content;
    }

    public Integer getHomework_count() {
        return homework_count;
    }

    public void setHomework_count(Integer homework_count) {
        this.homework_count = homework_count;
    }

    public String getHomework_leavetime() {
        return homework_leavetime;
    }

    public void setHomework_leavetime(String homework_leavetime) {
        this.homework_leavetime = homework_leavetime;
    }

    public String getHomework_finishtime() {
        return homework_finishtime;
    }

    public void setHomework_finishtime(String homework_finishtime) {
        this.homework_finishtime = homework_finishtime;
    }

    public String getHomework_reply() {
        return homework_reply;
    }

    public void setHomework_reply(String homework_reply) {
        this.homework_reply = homework_reply;
    }

    public Integer getFlag_reply() {
        return flag_reply;
    }

    public void setFlag_reply(Integer flag_reply) {
        this.flag_reply = flag_reply;
    }

    public Integer getFlag_finish() {
        return flag_finish;
    }

    public void setFlag_finish(Integer flag_finish) {
        this.flag_finish = flag_finish;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    @Override
    public String toString() {
        return "HomeWork{" +
                "id=" + id +
                ", homework_name='" + homework_name + '\'' +
                ", homework_content='" + homework_content + '\'' +
                ", homework_count=" + homework_count +
                ", homework_leavetime='" + homework_leavetime + '\'' +
                ", homework_finishtime='" + homework_finishtime + '\'' +
                ", homework_reply='" + homework_reply + '\'' +
                ", flag_reply=" + flag_reply +
                ", flag_finish=" + flag_finish +
                ", stu_id=" + stu_id +
                ", teacher_id=" + teacher_id +
                '}';
    }
}
