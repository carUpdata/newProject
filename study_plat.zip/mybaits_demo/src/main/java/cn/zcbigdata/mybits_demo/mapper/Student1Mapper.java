package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface Student1Mapper {

    public Student1 slogin(EasyStudentLogin easystudentlogin);

    public List<THomeWork> sHomeWorkSelectAll(Integer stu_id);

    //public THomeWork_Son sHomeWorkSelectSingle(Integer id);

    public THomeWork_Son sHomeWorkSelectSingle(StudentSelect studentselect);

    public int sHomeWorkInsertSingle(THomeWork1 thomework1);

    public int sHomeWorkUpdateSingle(THomeWork_Son thomework_son);

    public int sTakeLeaveInsert(TStudentTake_Leave sTakeLeaveSelect);

    public TStudentTake_Leave sTakeLeaveSelect(Integer stu_id);
}
