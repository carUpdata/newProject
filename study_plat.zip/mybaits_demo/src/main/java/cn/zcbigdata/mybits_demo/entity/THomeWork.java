package cn.zcbigdata.mybits_demo.entity;

public class THomeWork {
    private Integer id;
    private String homework_name;
    private Integer homework_count;
    private String homework_leave_time;
    private Integer teacher_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    public Integer getHomework_count() {
        return homework_count;
    }

    public void setHomework_count(Integer homework_count) {
        this.homework_count = homework_count;
    }

    public String getHomework_leave_time() {
        return homework_leave_time;
    }

    public void setHomework_leave_time(String homework_leave_time) {
        this.homework_leave_time = homework_leave_time;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    @Override
    public String toString() {
        return "homework{" +
                "id=" + id +
                ", homework_name='" + homework_name + '\'' +
                ", homework_count='" + homework_count + '\'' +
                ", homework_time='" + homework_leave_time + '\'' +
                ", teacher_id=" + teacher_id +
                '}';
    }
}
