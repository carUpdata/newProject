package cn.zcbigdata.mybits_demo.entity;

public class THomeWork1 {
    private Integer stu_id;
    private String homework_name;
    private Integer homework_count;
    private String homework_leave_time;
    private Integer teacher_id;
    private Integer flag_reply;
    private Integer flag_finish;

    public Integer getFlag_reply() {
        return flag_reply;
    }

    public void setFlag_reply(Integer flag_reply) {
        this.flag_reply = flag_reply;
    }

    public Integer getFlag_finish() {
        return flag_finish;
    }

    public void setFlag_finish(Integer flag_finish) {
        this.flag_finish = flag_finish;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    public Integer getHomework_count() {
        return homework_count;
    }

    public void setHomework_count(Integer homework_count) {
        this.homework_count = homework_count;
    }

    public String getHomework_leave_time() {
        return homework_leave_time;
    }

    public void setHomework_leave_time(String homework_leave_time) {
        this.homework_leave_time = homework_leave_time;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    @Override
    public String toString() {
        return "THomeWork1{" +
                "stu_id=" + stu_id +
                ", homework_name='" + homework_name + '\'' +
                ", homework_count=" + homework_count +
                ", homework_leave_time='" + homework_leave_time + '\'' +
                ", teacher_id=" + teacher_id +
                ", flag_reply=" + flag_reply +
                ", flag_finish=" + flag_finish +
                '}';
    }
}
