package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.TStudentTake_Leave;
import cn.zcbigdata.mybits_demo.entity.TTeacherTake_Leave;

import java.util.List;

public interface ManagerMapper {
    public List<TTeacherTake_Leave> mTeacherTakeLeave();

    public int mManagerUpdateTakeLeave(TTeacherTake_Leave tteachertake_leave);
}
