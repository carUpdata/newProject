package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.TTeacherTake_Leave;

import java.util.List;

public interface ManagerService {

    public List<TTeacherTake_Leave> mTeacherTakeLeave();

    public int mManagerUpdateTakeLeave(TTeacherTake_Leave tteachertake_leave);
}
