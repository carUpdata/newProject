package cn.zcbigdata.mybits_demo.entity;

public class Manager {
    private Integer id;
    private Integer manager_id;
    private String manager_name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getManager_id() {
        return manager_id;
    }

    public void setManager_id(Integer manager_id) {
        this.manager_id = manager_id;
    }

    public String getManager_name() {
        return manager_name;
    }

    public void setManager_name(String manager_name) {
        this.manager_name = manager_name;
    }

    @Override
    public String toString() {
        return "Manager{" +
                "id=" + id +
                ", manager_id=" + manager_id +
                ", manager_name='" + manager_name + '\'' +
                '}';
    }
}
