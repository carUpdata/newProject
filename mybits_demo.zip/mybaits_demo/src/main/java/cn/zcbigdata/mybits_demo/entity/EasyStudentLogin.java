package cn.zcbigdata.mybits_demo.entity;

public class EasyStudentLogin {
    private Integer stu_id;
    private String stu_password;
    private Integer teacher_id;
    private String teacher_password;

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_password() {
        return stu_password;
    }

    public void setStu_password(String stu_password) {
        this.stu_password = stu_password;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getTeacher_password() {
        return teacher_password;
    }

    public void setTeacher_password(String teacher_password) {
        this.teacher_password = teacher_password;
    }

    @Override
    public String toString() {
        return "EasyStudentLogin{" +
                "stu_id=" + stu_id +
                ", stu_password='" + stu_password + '\'' +
                ", teacher_id=" + teacher_id +
                ", teacher_password='" + teacher_password + '\'' +
                '}';
    }
}
