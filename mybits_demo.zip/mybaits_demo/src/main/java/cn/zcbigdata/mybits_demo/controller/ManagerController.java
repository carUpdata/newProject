package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.entity.TTeacherTake_Leave;
import cn.zcbigdata.mybits_demo.service.ManagerService;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/manager")
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    private static final Logger LOGGER = Logger.getLogger(ManagerController.class);//日志
    private static Gson gson = new Gson();


    //请假模块
    @ResponseBody
    @RequestMapping(value="/mTeacherTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String mTeacherTakeLeave(HttpServletRequest request, Model model){

        List<TTeacherTake_Leave> mteachertakeleavelist = managerService.mTeacherTakeLeave();
        LOGGER.info("输出参数"+" " +mteachertakeleavelist);//日志打印输出参数
        String data = gson.toJson(mteachertakeleavelist);
        return data;

    }

    @ResponseBody
    @RequestMapping(value="/mManagerUpdateTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String mManagerUpdateTakeLeave(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);

        Integer flagInteger = 1;

        if (StringUtils.isNotEmpty(IdString)){
            TTeacherTake_Leave tteachertakeleave =  new TTeacherTake_Leave();
            tteachertakeleave.setId(IdInteger);
            tteachertakeleave.setFlag(flagInteger);
            managerService.mManagerUpdateTakeLeave(tteachertakeleave);
            LOGGER.info("输出的参数"+" " +tteachertakeleave);//输出日志打印
            String data = gson.toJson(tteachertakeleave);
            return data;
        }
        String data = "{\"data\":\"没有教师的请假信息！\"}";
        return "data";
    }

}
