package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.TeacherService;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    private static final Logger LOGGER = Logger.getLogger(TeacherController.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/tlogin")
    public String ttologin(){
        LOGGER.info("Go To tlogin.html");
        return "tlogin";
    }

    @RequestMapping("/thomeworkselectall")
    public String thomeworkselectall(){
        LOGGER.info("Go To teacherHomeWork.html");
        return "teacherHomeWork";
    }

    @RequestMapping("/ttakeleave")
    public String ttakeleave(){
        LOGGER.info("Go To teacherTakeLeave.html");
        return "teacherTakeLeave";
    }
    @RequestMapping("/download")
    public String download(){
        LOGGER.info("Go To teacherClassScheduleDownload.html");
        return "teacherClassScheduleDownload";
    }
    @RequestMapping("/thomeworkson")
    public String thomeworkselectson(){
        LOGGER.info("Go To teacherHomeWorkSon.html");
        return "teacherHomeWorkSon";
    }
    @RequestMapping("/thomeworkmyson")
    public String thomeworkselectmyson(){
        LOGGER.info("Go To teacherHomeWorkMySon.html");
        return "teacherHomeWorkMySon";
    }

    //登录模块
    @RequestMapping(value="/ttologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String ttologin(HttpServletRequest request, Model model){
        String teacher_id = request.getParameter("teacher_id");
        String teacher_password = request.getParameter("teacher_password");
        Integer teacher_idInteger = Integer.valueOf(teacher_id);


        EasyStudentLogin easystudentlogin = new EasyStudentLogin();
        easystudentlogin.setTeacher_id(teacher_idInteger);
        easystudentlogin.setTeacher_password(teacher_password);
        boolean x = teacherService.tlogin(easystudentlogin,request);

        LOGGER.info("ttologin接收参数"+" " +easystudentlogin);

        if (x){
            HttpSession session = request.getSession();
            session.setAttribute("teacher_id", teacher_idInteger);

            LOGGER.info("登录成功");
            return "teacher";

        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }


    //作业模块
    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectAll(HttpServletRequest request, Model model){
        //String teacherIdString = request.getParameter("teacher_id");
        //Integer teacherIdInteger = Integer.valueOf(teacherIdString);
        HttpSession session = request.getSession();
        Integer teacherIdInteger = (Integer) session.getAttribute("teacher_id");

        LOGGER.info("tHomeWorkSelectAll接收参数"+" " +teacherIdInteger);//日志打印
        //if (StringUtils.isNotEmpty(teacherIdString)){
            THomeWork thomework =  new THomeWork();
            thomework.setTeacher_id(teacherIdInteger);
            List<THomeWork> thomeworklist = teacherService.tHomeWorkSelectAll(teacherIdInteger);
            System.out.println(thomeworklist);
            String data = gson.toJson(thomeworklist);
            return data;
        //}
        //String data = "{\"data\":\"teacherID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectSon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectSon(HttpServletRequest request, Model model){
        String homework_nameString = request.getParameter("homework_name");

        LOGGER.info("tHomeWorkSelectSon接收参数"+" " +homework_nameString);//日志打印
        if (StringUtils.isNotEmpty(homework_nameString)){
            THomeWork_Son thomework_son =  new THomeWork_Son();
            thomework_son.setHomework_name(homework_nameString);
            List<THomeWork_Son> thomeworksonlist = teacherService.tHomeWorkSelectSon(homework_nameString);
            System.out.println(thomeworksonlist);
            String data = gson.toJson(thomeworksonlist);
            return data;
        }
        String data = "{\"data\":\"ID不能为空！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectMySon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectMySon(HttpServletRequest request, Model model){

        String homeworknameString = request.getParameter("homework_name");
        String studentnameString = request.getParameter("stu_name");
        HomeSelect homeselect = new HomeSelect();

        homeselect.setHomework_name(homeworknameString);
        homeselect.setStu_name(studentnameString);

        THomeWork_Son thomeworkmyson = teacherService.tHomeWorkSelectMySon(homeselect);
        String data = gson.toJson(thomeworkmyson);
        LOGGER.info("tHomeWorkSelectMySon接收参数"+" " +data);//日志打印
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateHomeWork", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateHomeWork(HttpServletRequest request, Model model){
        String homeworknameString = request.getParameter("homework_name");
        String studentnameString = request.getParameter("stu_name");
        String teacherreplyString = request.getParameter("teacher_reply");
        Integer flagInteger = 1;

        //if (StringUtils.isNotEmpty(IdString)){
            THomeWork_Son thomeworkson =  new THomeWork_Son();
            thomeworkson.setHomework_name(homeworknameString);
            thomeworkson.setStu_name(studentnameString);
            thomeworkson.setTeacher_reply(teacherreplyString);
            thomeworkson.setFlag1(flagInteger);
            teacherService.tHomeWorkUpdate(thomeworkson);
            String data = gson.toJson(thomeworkson);
            LOGGER.info("tTeacherUpdateHomeWork接收参数"+" " +thomeworkson);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkInsert(HttpServletRequest request, Model model){
        String homework_nameString = request.getParameter("homework_name");
        Date date = new Date();
        String homework_timeString = date.toString();

        HttpSession session = request.getSession();
        Integer teacher_idInteger = (Integer) session.getAttribute("teacher_id");

        Integer homework_countInteger = 0;

        THomeWork thomework =  new THomeWork();
        thomework.setHomework_name(homework_nameString);
        thomework.setHomework_time(homework_timeString);
        thomework.setTeacher_id(teacher_idInteger);
        thomework.setHomework_count(homework_countInteger);

        LOGGER.info("tHomeWorkInsert接收参数"+" " +thomework);//日志打印

        teacherService.tHomeWorkInsert(thomework);
        String data = "{\"data\":\"插入成功！\"}";
        return data;
    }

    //请假模块
    @ResponseBody
    @RequestMapping(value="/tStudentTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tStudentTakeLeave(HttpServletRequest request, Model model){
//        String teacherIdString = request.getParameter("teacher_id");
//        Integer teacherIdInteger = Integer.valueOf(teacherIdString);

        HttpSession session = request.getSession();
        Integer teacherIdInteger = (Integer) session.getAttribute("teacher_id");

        //if (StringUtils.isNotEmpty(teacherIdString)){
            TStudentTake_Leave tstudenttakeleave =  new TStudentTake_Leave();
            tstudenttakeleave.setTeacher_id(teacherIdInteger);
            List<TStudentTake_Leave> tstudenttakeleavelist = teacherService.tStudentTakeLeave(teacherIdInteger);

            String data = gson.toJson(tstudenttakeleavelist);
            LOGGER.info("tStudentTakeLeave接收参数"+" " +tstudenttakeleavelist);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateTakeLeave(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);

        Integer flagInteger = 1;

        if (StringUtils.isNotEmpty(IdString)){
            TStudentTake_Leave tstudenttakeleave =  new TStudentTake_Leave();
            tstudenttakeleave.setId(IdInteger);
            tstudenttakeleave.setFlag(flagInteger);
            teacherService.tTeacherUpdateTakeLeave(tstudenttakeleave);
            String data = gson.toJson(tstudenttakeleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
            return data;
        }
        String data = "{\"data\":\"没有学生的请假信息！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTakeLeaveInsert(HttpServletRequest request, Model model){

        HttpSession session = request.getSession();
        Integer teacherIdInteger = (Integer) session.getAttribute("teacher_id");

        Integer flagInteger = 0;
        String teacherNameString = request.getParameter("teacher_name");
        String teacherLeaveReasonString = request.getParameter("teacher_leave_reason");
        Date date = new Date();
        String teacherLeaveTimeString = date.toString();

        //if (StringUtils.isNotEmpty(teacherIdString)){
            TTeacherTake_Leave tleave =  new TTeacherTake_Leave();
            tleave.setTeacher_id(teacherIdInteger);
            tleave.setFlag(flagInteger);
            tleave.setTeacher_name(teacherNameString);
            tleave.setTeacher_leave_reason(teacherLeaveReasonString);
            tleave.setTeacher_leave_time(teacherLeaveTimeString);
            teacherService.tTakeLeaveInsert(tleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tleave);//日志打印
            String data = gson.toJson(tleave);
            return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return "data";
    }
}
