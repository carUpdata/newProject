package cn.zcbigdata.mybits_demo.entity;

public class StudentSelect {
    private Integer stu_id;
    private String homework_name;

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    @Override
    public String toString() {
        return "studentSelect{" +
                "stu_id=" + stu_id +
                ", homework_name='" + homework_name + '\'' +
                '}';
    }
}
