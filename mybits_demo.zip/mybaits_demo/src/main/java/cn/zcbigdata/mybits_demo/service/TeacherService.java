package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


public interface TeacherService {

    public Boolean tlogin(EasyStudentLogin easystudentlogin, HttpServletRequest request);

    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id);

    public List<THomeWork_Son> tHomeWorkSelectSon(String homework_name);

    public THomeWork_Son tHomeWorkSelectMySon(HomeSelect homeselect);

    public int tHomeWorkUpdate(THomeWork_Son thomeworkson);

    public int tHomeWorkInsert(THomeWork thomework);

    public List<TStudentTake_Leave> tStudentTakeLeave(Integer teacher_id);

    public int tTeacherUpdateTakeLeave(TStudentTake_Leave tstudenttake_leave);

    public int tTakeLeaveInsert(TTeacherTake_Leave tleave);
}
