package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.Student1Service;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/student1")
public class Student1Controller {
    @Autowired
    private Student1Service student1Service;

    private static final Logger LOGGER = Logger.getLogger(Student1Controller.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/slogin")
    public String stologin(){
        LOGGER.info("Go To slogin.html");
        return "slogin";
    }

    @RequestMapping("/shomeworkselectall")
    public String shomeworkselectall(){
        LOGGER.info("Go To studentWriteHomeWork.html");
        return "studentWriteHomeWork";
    }
    @RequestMapping("/stakeleave")
    public String stakeleave(){
        LOGGER.info("Go To studentTakeLeave.html");
        return "studentTakeLeave";
    }
    @RequestMapping("/download")
    public String download(){
        LOGGER.info("Go To studentClassScheduleDownload.html");
        return "studentClassScheduleDownload";
    }

    @RequestMapping("/studentwritehomeworkson")
    public String studentwritehomeworkson(){
        LOGGER.info("Go To studentWriteHomeWorkSon.html");
        return "studentWriteHomeWorkSon";
    }


    //登录模块
    @RequestMapping(value="/stologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String stologin(HttpServletRequest request, Model model){
        String stu_id = request.getParameter("stu_id");
        String stu_password = request.getParameter("stu_password");
        Integer stu_idInteger = Integer.valueOf(stu_id);


        EasyStudentLogin easystudentlogin = new EasyStudentLogin();
        easystudentlogin.setStu_id(stu_idInteger);
        easystudentlogin.setStu_password(stu_password);
        boolean x = student1Service.slogin(easystudentlogin,request);

        LOGGER.info("stologin接收参数"+" " +easystudentlogin);

        if (x){
            HttpSession session = request.getSession();
            session.setAttribute("stu_id", stu_idInteger);

//            System.out.println("------------------");
//            System.out.println(session.getAttribute("stu_id"));

            LOGGER.info("登录成功");
            return "student";

        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }

    //作业模块
    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectAll(HttpServletRequest request, Model model){

        HttpSession session = request.getSession();
        //String studentIdString = (String) session.getAttribute("stu_id");
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");

        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+studentIdInteger);//日志打印
        //if (StringUtils.isNotEmpty(studentIdString)){

        List<THomeWork> shomeworklist = student1Service.sHomeWorkSelectAll(studentIdInteger);

        String data = gson.toJson(shomeworklist);
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+data);//日志打印
        return data;
        //}
        //String data = "{\"data\":\"studentID不能为空！\"}";

        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectSingle(HttpServletRequest request, Model model){
        String homework_name = request.getParameter("homework_name");
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");

        System.out.println(homework_name+" "+studentIdInteger);

        StudentSelect studentselect = new StudentSelect();
        studentselect.setStu_id(studentIdInteger);
        studentselect.setHomework_name(homework_name);

        List<THomeWork_Son> shomeworksingle = student1Service.sHomeWorkSelectSingle(studentselect);
        System.out.println(studentselect+"*****");
        //String[] cloumns = {"id","homework_name","stu_name","homework_content","teacher_reply","flag","homework_write_time","stu_id"};
        String data = gson.toJson(shomeworksingle);

        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+data);//日志打印
        return data;
        //}
        //String data = "{\"data\":\"ID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkUpdateSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkUpdateSingle(HttpServletRequest request, Model model){
        String homeworknameString = request.getParameter("homework_name");
        String homeworkcontentString = request.getParameter("homework_content");
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");
        Integer flagInteger = 1;
        String homeworkcountString = request.getParameter("homework_count");
        Integer homeworkcountInteger = Integer.valueOf(homeworkcountString);
        Integer homework_count = homeworkcountInteger+1;

        THomeWork_Son thomework_son = new THomeWork_Son();
        thomework_son.setHomework_content(homeworkcontentString);

        thomework_son.setHomework_name(homeworknameString);
        thomework_son.setFlag(flagInteger);
        thomework_son.setStu_id(studentIdInteger);
        thomework_son.setHomework_count(homework_count);

        student1Service.sHomeWorkUpdateSingle(thomework_son);
        System.out.println(thomework_son);
        String data = "{\"data\":\"作业完成！\"}";
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");

        Integer flagInteger = 0;
        String studentNameString = request.getParameter("stu_name");
        String studentLeaveReasonString = request.getParameter("stu_leave_reason");
        String teacherIdString = request.getParameter("teacher_id");
        Integer teacherIdInteger = Integer.parseInt(teacherIdString);
        Date date = new Date();
        String studentLeaveTimeString = date.toString();

        //if (StringUtils.isNotEmpty(studentIdString)){
        TStudentTake_Leave tstudenttakeleave =  new TStudentTake_Leave();
        tstudenttakeleave.setStu_id(studentIdInteger);
        tstudenttakeleave.setFlag(flagInteger);
        tstudenttakeleave.setStu_name(studentNameString);
        tstudenttakeleave.setTeacher_id(teacherIdInteger);
        tstudenttakeleave.setStu_leave_reason(studentLeaveReasonString);
        tstudenttakeleave.setStu_leave_time(studentLeaveTimeString);
        student1Service.sTakeLeaveInsert(tstudenttakeleave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
        String data = gson.toJson(tstudenttakeleave) + "{\"data\":\"请假成功！\"}";
        return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Integer studentIdInteger = (Integer) session.getAttribute("stu_id");
        System.out.println(studentIdInteger);


        TStudentTake_Leave tstudenttake_leave = student1Service.sTakeLeaveSelect(studentIdInteger);
        String data = gson.toJson(tstudenttake_leave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttake_leave);//日志打印
        return data;

    }
}
