package cn.zcbigdata.mybits_demo.entity;

public class THomeWork_Son {
    private Integer id;
    private String homework_name;
    private String stu_name;
    private String homework_content;
    private String teacher_reply;
    private Integer flag;
    private Integer flag1;
    private String homework_write_time;
    private Integer stu_id;
    private Integer homework_count;

    public Integer getHomework_count() {
        return homework_count;
    }

    public void setHomework_count(Integer homework_count) {
        this.homework_count = homework_count;
    }

    public Integer getFlag1() {
        return flag1;
    }

    public void setFlag1(Integer flag1) {
        this.flag1 = flag1;
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public String getHomework_write_time() {
        return homework_write_time;
    }

    public void setHomework_write_time(String homework_write_time) {
        this.homework_write_time = homework_write_time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getHomework_content() {
        return homework_content;
    }

    public void setHomework_content(String homework_content) {
        this.homework_content = homework_content;
    }

    public String getTeacher_reply() {
        return teacher_reply;
    }

    public void setTeacher_reply(String teacher_reply) {
        this.teacher_reply = teacher_reply;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "THomeWork_Son{" +
                "id=" + id +
                ", homework_name='" + homework_name + '\'' +
                ", stu_name='" + stu_name + '\'' +
                ", homework_content='" + homework_content + '\'' +
                ", teacher_reply='" + teacher_reply + '\'' +
                ", flag=" + flag +
                ", flag1=" + flag1 +
                ", homework_write_time='" + homework_write_time + '\'' +
                ", stu_id=" + stu_id +
                ", homework_count=" + homework_count +
                '}';
    }
}
