package cn.zcbigdata.mybits_demo.entity;

public class Teacher {
    private Integer id;
    private Integer teacher_id;
    private String teacher_name;
    private String teacher_grade;
    private Integer manager_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public String getTeacher_grade() {
        return teacher_grade;
    }

    public void setTeacher_grade(String teacher_grade) {
        this.teacher_grade = teacher_grade;
    }

    public Integer getManager_id() {
        return manager_id;
    }

    public void setManager_id(Integer manager_id) {
        this.manager_id = manager_id;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "id=" + id +
                ", teacher_id=" + teacher_id +
                ", teacher_name='" + teacher_name + '\'' +
                ", teacher_grade='" + teacher_grade + '\'' +
                ", manager_id=" + manager_id +
                '}';
    }
}
