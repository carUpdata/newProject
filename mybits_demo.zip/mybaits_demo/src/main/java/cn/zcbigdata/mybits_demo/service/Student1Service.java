package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface Student1Service {

    public Boolean slogin(EasyStudentLogin easystudentlogin, HttpServletRequest request);

    public List<THomeWork> sHomeWorkSelectAll(Integer stu_id);

    //public THomeWork_Son sHomeWorkSelectSingle(Integer id);

    public List<THomeWork_Son> sHomeWorkSelectSingle(StudentSelect studentselect);

    int sHomeWorkUpdateSingle(THomeWork_Son thomework_son);

    public int sTakeLeaveInsert(TStudentTake_Leave sTakeLeaveSelect);

    public TStudentTake_Leave sTakeLeaveSelect(Integer stu_id);
}
