package cn.zcbigdata.mybits_demo.entity;

public class HomeSelect {
    private String stu_name;
    private String homework_name;

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getHomework_name() {
        return homework_name;
    }

    public void setHomework_name(String homework_name) {
        this.homework_name = homework_name;
    }

    @Override
    public String toString() {
        return "HomeSelect{" +
                "stu_name='" + stu_name + '\'' +
                ", homework_name='" + homework_name + '\'' +
                '}';
    }
}
