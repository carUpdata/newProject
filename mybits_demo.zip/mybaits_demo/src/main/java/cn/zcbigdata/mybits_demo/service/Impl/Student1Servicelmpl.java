package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.mapper.Student1Mapper;
import cn.zcbigdata.mybits_demo.service.Student1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Service
public class Student1Servicelmpl implements Student1Service {

    @Autowired
    private Student1Mapper student1Mapper;

    public Boolean slogin(EasyStudentLogin easystudentlogin, HttpServletRequest request){
        Student1 student1 = student1Mapper.slogin(easystudentlogin);
        if (student1 != null){
            HttpSession session = request.getSession();
            session.setAttribute("stu_id", student1.getId());
            return true;
        }
        return false;
    }

    public List<THomeWork> sHomeWorkSelectAll(Integer stu_id){
        return student1Mapper.sHomeWorkSelectAll(stu_id);
    }

//    public THomeWork_Son sHomeWorkSelectSingle(Integer id){
//        return student1Mapper.sHomeWorkSelectSingle(id);
//    }

    public List<THomeWork_Son> sHomeWorkSelectSingle(StudentSelect studentselect){
        return student1Mapper.sHomeWorkSelectSingle(studentselect);
    }

    public int sHomeWorkUpdateSingle(THomeWork_Son thomework_son){
        return student1Mapper.sHomeWorkUpdateSingle(thomework_son);
    }

    public int sTakeLeaveInsert(TStudentTake_Leave sTakeLeaveSelect){
        return student1Mapper.sTakeLeaveInsert(sTakeLeaveSelect);
    }

    public TStudentTake_Leave sTakeLeaveSelect(Integer stu_id){
        return student1Mapper.sTakeLeaveSelect(stu_id);
    }
}
