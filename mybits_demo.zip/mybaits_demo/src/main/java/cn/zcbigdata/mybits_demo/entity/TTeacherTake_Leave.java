package cn.zcbigdata.mybits_demo.entity;

public class TTeacherTake_Leave {
    private Integer id;
    private Integer teacher_id;
    private String teacher_name;
    private String teacher_leave_reason;
    private String teacher_leave_time;
    private Integer flag;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }

    public String getTeacher_leave_reason() {
        return teacher_leave_reason;
    }

    public void setTeacher_leave_reason(String teacher_leave_reason) {
        this.teacher_leave_reason = teacher_leave_reason;
    }

    public String getTeacher_leave_time() {
        return teacher_leave_time;
    }

    public void setTeacher_leave_time(String teacher_leave_time) {
        this.teacher_leave_time = teacher_leave_time;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "TLeave{" +
                "id=" + id +
                ", teacher_id=" + teacher_id +
                ", teacher_name='" + teacher_name + '\'' +
                ", teacher_leave_reason='" + teacher_leave_reason + '\'' +
                ", teacher_leave_time='" + teacher_leave_time + '\'' +
                ", flag=" + flag +
                '}';
    }
}
