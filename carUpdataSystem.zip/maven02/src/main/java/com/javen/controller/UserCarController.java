package com.javen.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javan.util.ObjtoLayJson;
import com.javen.model.Union;
import com.javen.model.UserCar;
import com.javen.model.UserPage;
import com.javen.model.UserUpKeep;
import com.javen.model.dataCheck;
import com.javen.model.UserPage;
import com.javen.service.UserCarService;

@Controller
@RequestMapping("/usercar")
public class UserCarController {

	@Autowired
	private UserCarService usercarService;
	
	
	@ResponseBody
	@RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String selectAll(HttpServletRequest request) throws Exception{
		request.setCharacterEncoding("utf-8");  

    	String pageString = request.getParameter("page");
    	String limitString = request.getParameter("limit");
    	String user_idnumberString = request.getParameter("user_idnumber");
    	System.out.println(pageString+" "+limitString+" "+user_idnumberString);
    	Integer pageInteger = Integer.valueOf(pageString);
    	Integer limitInteger = Integer.valueOf(limitString);
    	
    	
    	UserPage userpage= new UserPage();
    	
    	userpage.setPage(pageInteger-1);
    	userpage.setLimit(limitInteger);
    	userpage.setOffset((pageInteger-1)*limitInteger);
    	userpage.setUser_idnumber(user_idnumberString);
    	
    	
    	List<Union> usercarss = usercarService.selectAll(userpage);
      	String[] colums = {"id","car_name","car_mile","car_src","flag","car_id","user_idnumber"};
    	String data = ObjtoLayJson.ListtoJson(usercarss, colums);
    	System.out.println(data);
        return data; 
	}
	
	@ResponseBody
	@RequestMapping(value="/selectAll_count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String selectAll_count(){
		int countAll = usercarService.selectAll_count();
		String data = "{\"data\":\"200\",\"count\":\""+countAll+"\"}";
		System.out.println(data);
		 return data;
		
	}
	
	@ResponseBody
	@RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	public String deleteByPrimaryId(int id) {
		 usercarService.deleteByPrimaryKey(id);
		 String data ="{\"data\":\"删除成功\"}";
		return data;
	}
	
	@ResponseBody
	@RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
	public String insert(String car_name,String car_mile,String car_src,String flag,String car_id) {
		UserCar Car = new UserCar();
		String data = "";
    	try {
    		Car.setCar_mile(dataCheck.check2(car_mile));
    		Car.setFlag(dataCheck.check3(flag));
    		Car.setCar_id(dataCheck.check4(car_id));
    		 data="{\"data\":\"插入成功\"}";
    	}catch(Exception e){
    		data = "{\"data\":"+e.getMessage()+"}" ;
    	}
    	Car.setCar_name(car_name);
    	Car.setCar_src(car_src);
    	usercarService.insert(Car);
		return data;
	}
	
		@ResponseBody
	    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	    public String update(String id,String car_name,String car_mile,String car_src,String flag,String car_id) throws Exception {
	    	UserCar Car = new UserCar();
	    	String data = "";
	    	try {
	    		Car.setId(dataCheck.check1(id));
	    		Car.setCar_mile(dataCheck.check2(car_mile));
	    		Car.setFlag(dataCheck.check3(flag));
	    		Car.setCar_id(dataCheck.check4(car_id));
	    		 data = "{\"data\":\"修改成功\"}"; 
	    	}catch(Exception e){
	    		data = "{\"data\":"+e.getMessage()+"}" ;
	    	}
	    	Car.setCar_name(car_name);
	    	Car.setCar_src(car_src);
	    	usercarService.updateByPrimaryKey(Car);
	        return data; 
	    }
	

}
