package com.javen.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import com.javen.dao.UserCarDao;
import com.javen.model.Union;
import com.javen.model.UserCar;
import com.javen.model.UserPage;
import com.javen.service.UserCarService;

@Service
public class UserCarServiceImpl implements UserCarService{

	@Resource
	private UserCarDao usercarDao;
	
	public List<Union> selectAll(UserPage userpage) {
		// TODO Auto-generated method stub
		return this.usercarDao.selectAll(userpage);
	}
	
	public int updateByPrimaryKey(UserCar Car) {
		return this.usercarDao.updateByPrimaryKey(Car);
	}
	
	public int deleteByPrimaryKey(int id) {
		return  this.usercarDao.deleteByPrimaryKey(id);	
	}
	
	public int insert(UserCar usercar) {
		return this.usercarDao.insert(usercar);
	}
	
	public int selectAll_count() {
		return  this.usercarDao.selectAll_count();
	}
	
	/*public int selectAll_flag() {
		// TODO Auto-generated method stub
		return this.usercarDao.selectAll_flag();
	}*/
}
