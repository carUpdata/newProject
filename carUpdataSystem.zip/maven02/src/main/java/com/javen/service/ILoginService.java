package com.javen.service;

import java.util.List;

import com.javen.model.Login;



public interface ILoginService {
	
	
	 public Login selectByPrimaryKey(int id);
	 
	 public int deleteByPrimaryKey(int id);
	 
	 public int insert(Login login);
	 
	 public int updateByPrimaryKey(Login login);
	 
	 public List<Login> selectAll();
	 
	 public boolean login(Login login);
	 
	 //public boolean login2(Login login);
}
