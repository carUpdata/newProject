package com.javen.service;

import java.util.List;

import com.javen.model.User;
import com.javen.model.UserUpKeep;
import com.javen.model.UserPage;

public interface UserUpKeepService {
	
	 public boolean login(User user) ;
	 
	 public int deleteByPrimaryKey(int id);
	 
	 public int insert(UserUpKeep upkeep);
	 
	 public int updateByPrimaryKey(UserUpKeep upkeep);
	 
	 public int selectAll_count();
	
	 
	 public List<UserUpKeep> selectAll(UserPage userpage);
}
