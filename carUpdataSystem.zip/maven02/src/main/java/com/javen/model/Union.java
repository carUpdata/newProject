package com.javen.model;

public class Union {
	private Integer id;
	private String car_name;
	private Integer car_mile;
	private String car_src;
	private Integer flag;
	private Integer car_id;
	private String user_idnumber;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCar_name() {
		return car_name;
	}
	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}
	public Integer getCar_mile() {
		return car_mile;
	}
	public void setCar_mile(Integer car_mile) {
		this.car_mile = car_mile;
	}
	public String getCar_src() {
		return car_src;
	}
	public void setCar_src(String car_src) {
		this.car_src = car_src;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	public Integer getCar_id() {
		return car_id;
	}
	public void setCar_id(Integer car_id) {
		this.car_id = car_id;
	}
	public String getUser_idnumber() {
		return user_idnumber;
	}
	public void setUser_idnumber(String user_idnumber) {
		this.user_idnumber = user_idnumber;
	}
	@Override
	public String toString() {
		return "Union [id=" + id + ", car_name=" + car_name + ", car_mile=" + car_mile + ", car_src=" + car_src
				+ ", flag=" + flag + ", car_id=" + car_id + ", user_idnumber=" + user_idnumber + "]";
	}
	
	
}
