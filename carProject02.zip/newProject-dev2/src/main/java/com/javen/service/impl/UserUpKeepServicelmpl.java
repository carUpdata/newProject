package com.javen.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javen.dao.UserUpKeepDao;
import com.javen.model.UserPage;
import com.javen.model.UserUpKeep;
import com.javen.model.User;
import com.javen.service.UserUpKeepService;

@Service
public class UserUpKeepServicelmpl implements UserUpKeepService{
	@Autowired
	private UserUpKeepDao userupkeepDao;
	
	public boolean login(User user) {
		
		List<User> users = userupkeepDao.login(user);
		
		if(users.size() == 1) {
			return true;
		}
		
		return false;
	}
	
	/*public UpKeep selectByPrimaryKey(int id) {
		// TODO Auto-generated method stub
		return this.UpKeepDao.selectByPrimaryKey(id);
	}*/

	public int deleteByPrimaryKey(int id) {
		// TODO Auto-generated method stub
		return this.userupkeepDao.deleteByPrimaryKey(id);
	}

	public int selectAll_count() {
		// TODO Auto-generated method stub
		return this.userupkeepDao.selectAll_count();
	}
	
	
	
	public List<UserUpKeep> selectAll(UserPage userpage) {
		// TODO Auto-generated method stub
		return this.userupkeepDao.selectAll(userpage);
	}

	public int insert(UserUpKeep userupkeep) {
		return this.userupkeepDao.insert(userupkeep);
	}

	public int updateByPrimaryKey(UserUpKeep userupkeep) {
		// TODO Auto-generated method stub
		return this.userupkeepDao.updateByPrimaryKey(userupkeep);
	}

}
