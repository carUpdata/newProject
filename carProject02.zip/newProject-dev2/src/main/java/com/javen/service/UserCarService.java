package com.javen.service;

import java.util.List;

import com.javen.model.Union;
import com.javen.model.UserCar;
import com.javen.model.UserPage;

public interface UserCarService {

	//public List<UserCar> selectAll(UserPage userpage);
	
	public List<Union> selectAll(UserPage userpage);
	
	public int updateByPrimaryKey(UserCar Car);
	
	public int deleteByPrimaryKey(int id);
	
	public int insert(UserCar Car);
	
	public int selectAll_count();
	
	 //public int selectAll_flag();
}
