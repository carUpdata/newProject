package com.javen.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javan.util.ObjtoLayJson;
//import com.javen.controller.ManagerUpKeepController.dataCheck;
import com.javen.model.UserPage;
import com.javen.model.UserUpKeep;
import com.javen.model.User;
import com.javen.model.UserPage;
import com.javen.service.UserUpKeepService;

@Controller  //返回指定页面  ajax 不能接受到页面的返回 ，所以说
@RequestMapping("/userupkeep") 
public class UserUpKeepController {
	
	private static Logger log=LoggerFactory.getLogger(UserUpKeepController.class);
	
	@Autowired   
	private UserUpKeepService userupKeepService;     
	
	@ResponseBody
    @RequestMapping(value="/login", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String login(HttpServletRequest request) throws Exception {
		
    	String user_idnumberString = request.getParameter("user_idnumber");
    	String user_passwordString = request.getParameter("user_password");
    	
    	User user = new User();
    	user.setUser_idnumber(user_idnumberString); 
    	user.setUser_password(user_passwordString); 
    	
    	boolean x = userupKeepService.login(user);
    	String jsonString = "";
    	if(x) {
    		jsonString = "{\"message\":\"登录成功！\"}";
    	}else {
    		jsonString = "{\"message\":\"登录失败！\"}";
    	}
    	return jsonString;
    }
	
	@ResponseBody
	@RequestMapping(value="/selectAll_count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8") 
    public String count(HttpServletRequest request) throws Exception{  
		int countAll = userupKeepService.selectAll_count();
		System.out.println("总的数据条数："+countAll);
		String data = "{\"count\": \""+countAll+"\"}";
		System.out.println(data);
        return data;
    }
	
	@ResponseBody
    @RequestMapping(value="/delete", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	public String deleteByPrimaryKey(int id) {//这样传参直接接收
	    //public String deleteByPrimaryKey(HttpServletRequest request) {
	    	//String  idString = request.getParameter("id");
	    	//Integer idInteger = Integer.valueOf(idString);
	    	//UpKeepService.deleteByPrimaryKey(idInteger);
	    	System.out.println("删除的id："+id);//这样传参直接接收
	    	
	    	userupKeepService.deleteByPrimaryKey(id);
	    	String data = "{\"data\":\"返回删除成功\"}"; 
	        return data; 
	    }
	    
	    @ResponseBody
	    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	    //public String insert(int car_id,String upkeep_date,String upkeep_distance,String upkeep_account,String upkeep_cost,String upkeep_date,String upkeep_distance) {
	    public String insert(HttpServletRequest request) {
	    //插入数据库
	    	
	    	String  car_idString = request.getParameter("car_id");
	    	String upkeep_dateString = request.getParameter("upkeep_date");
	    	String upkeep_distanceString = request.getParameter("upkeep_distance");
	    	String upkeep_accountString = request.getParameter("upkeep_account");
	    	String upkeep_costString = request.getParameter("upkeep_cost");
	    	String upkeep_addressString = request.getParameter("upkeep_address");
	    	String user_idnumberString = request.getParameter("user_idnumber");
	    	
	    	UserUpKeep userupkeep = new UserUpKeep();
	    	
	    	try {
	    		userupkeep.setCar_id(dataCheck.check1(car_idString));
	    		
	    	}catch(Exception e){
	    		e.getMessage();
	    	}
	    	
	    	userupkeep.setUpkeep_date(upkeep_dateString);
	    	userupkeep.setUpkeep_distance(upkeep_distanceString);
	    	userupkeep.setUpkeep_account(upkeep_accountString);
	    	userupkeep.setUpkeep_cost(upkeep_costString);
	    	userupkeep.setUpkeep_address(upkeep_addressString);
	    	userupkeep.setUser_idnumber(user_idnumberString);
	    	
	    	userupKeepService.insert(userupkeep);
	    	//System.out.print("插入");
	    	
	    	//给前台返回的东西
	    	String data = "{\"data\":\"返回插入成功\"}"; 
	        return data; 
	    }
	    
	    @ResponseBody
	    @RequestMapping(value="/update", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	    public String update(HttpServletRequest request) throws Exception {
	    	//修改内容
	    	String idString = request.getParameter("id");
	    	String car_idString = request.getParameter("car_id");
	    	String upkeep_dateString = request.getParameter("upkeep_date");
	    	String upkeep_distanceString = request.getParameter("upkeep_distance");
	    	String upkeep_accountString = request.getParameter("upkeep_account");
	    	String upkeep_costString = request.getParameter("upkeep_cost");
	    	String upkeep_addressString = request.getParameter("upkeep_address");
	    	String user_idnumberString = request.getParameter("user_idnumber");
	    	
	    	UserUpKeep userupkeep = new UserUpKeep();
	    	//校验，调用方法
	    	
	    	String data = "";
	    	try {
	    		userupkeep.setId(dataCheck.check1(idString));
	    		userupkeep.setCar_id(dataCheck.check2(car_idString));
	    		  
	    	}catch(Exception e){
	    		e.getMessage();
	    	}
	    	
	    	
	    	
	    	userupkeep.setUpkeep_date(upkeep_dateString);
	    	userupkeep.setUpkeep_distance(upkeep_distanceString);
	    	userupkeep.setUpkeep_account(upkeep_accountString);
	    	userupkeep.setUpkeep_cost(upkeep_costString);
	    	userupkeep.setUpkeep_address(upkeep_addressString);
	    	userupkeep.setUser_idnumber(user_idnumberString);	
	    	
	    	userupKeepService.updateByPrimaryKey(userupkeep);
	    	//System.out.println("修改前数据的id："+idString);
	    	//System.out.println("修改后数据的地址："+upkeep_addressString);
	    	
	    	data = "{\"status\":\"0\",\"data\":\"修改成功！\"}";
	        return data; 
	    }
	    

		//返回字符串
	    @ResponseBody
	    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
	    public String selectAll(HttpServletRequest request) throws Exception{  	  
	    	
	    	request.setCharacterEncoding("utf-8");  
	    	String pageString = request.getParameter("page");
	    	String limitString = request.getParameter("limit");
	    	String user_idnumberString = request.getParameter("user_idnumber");
	    	Integer pageInteger = Integer.valueOf(pageString);
	    	Integer limitInteger = Integer.valueOf(limitString);   
	    	//Integer pageInteger = 1;
	    	//Integer limitInteger = 10;
	    	
	    	UserPage userpage= new UserPage();
	    	
	    	userpage.setPage(pageInteger);
	    	userpage.setLimit(limitInteger);
	    	userpage.setOffset((pageInteger-1)*limitInteger);
	    	userpage.setUser_idnumber(user_idnumberString);
	    	
	    	List<UserUpKeep> userupkeeps = userupKeepService.selectAll(userpage);
	    	
	      	String[] colums = {"id","car_id","upkeep_date","upkeep_distance","upkeep_account","upkeep_cost","upkeep_address","user_idnumber"};
	    	String data = ObjtoLayJson.ListtoJson(userupkeeps, colums);
	    	return data; 
	    }
	   
	    public static class dataCheck {	
	    	public static int check1(String x) throws Exception{
	    		try {
	    			 return Integer.parseInt(x);
	    		}catch(Exception e) {
	    			throw new Exception("id参数有问题");
	    		}
	    	}
	    	
	    	public static int check2(String x) throws Exception{
	    		try {
	    			return Integer.parseInt(x);
	    		}catch(Exception e) {
	    			throw new Exception("车牌号有问题");
	    		}
	    	}
	    }
}
