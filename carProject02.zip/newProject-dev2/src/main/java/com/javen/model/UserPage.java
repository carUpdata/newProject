package com.javen.model;

public class UserPage {

	public Integer page;
	public Integer offset;
	public Integer limit ;
	public String user_idnumber;
	
	
	
	public Integer getPage() {
		return page;
	}



	public void setPage(Integer page) {
		this.page = page;
	}



	public Integer getOffset() {
		return offset;
	}



	public void setOffset(Integer offset) {
		this.offset = offset;
	}



	public Integer getLimit() {
		return limit;
	}



	public void setLimit(Integer limit) {
		this.limit = limit;
	}



	public String getUser_idnumber() {
		return user_idnumber;
	}



	public void setUser_idnumber(String user_idnumber) {
		this.user_idnumber = user_idnumber;
	}



	@Override
	public String toString() {
		return "UserPage [page=" + page + ", offset=" + offset + ", limit=" + limit + ", user_idnumber=" + user_idnumber
				+ "]";
	}
	
}
