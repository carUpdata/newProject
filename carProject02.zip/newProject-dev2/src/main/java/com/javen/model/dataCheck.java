package com.javen.model;

public class dataCheck {

	
	public static int check1(String x) throws Exception{
		try {
			 return Integer.parseInt(x);
		}catch(Exception e) {
			throw new Exception("id参数有问题");
		}
	}
	
	public static int check2(String x) throws Exception{
		try {
			return Integer.parseInt(x);
		}catch(Exception e) {
			throw new Exception("里程参数有问题");
		}
	}
	
	public static int check3(String x) throws Exception{
		try {
			return Integer.parseInt(x);
		}catch(Exception e) {
			throw new Exception("flag参数有问题");
		}
	}
	
	public static int check4(String x) throws Exception{
		try {
			return Integer.parseInt(x);
		}catch(Exception e) {
			throw new Exception("车牌参数有问题");
		}
	}
	
	
}
