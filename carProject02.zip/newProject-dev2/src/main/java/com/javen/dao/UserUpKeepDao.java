package com.javen.dao;

import java.util.List;

import com.javen.model.UserPage;
import com.javen.model.UserUpKeep;
import com.javen.model.User;

public interface UserUpKeepDao {
	
	public List<User> login(User user) ;
	
	public int deleteByPrimaryKey(int id);
	 
	 public int insert(UserUpKeep userupkeep);
	 
	 public int updateByPrimaryKey(UserUpKeep userupkeep);
	 
	 public int selectAll_count();
	 	 
	 public List<UserUpKeep> selectAll(UserPage userpage);
}
